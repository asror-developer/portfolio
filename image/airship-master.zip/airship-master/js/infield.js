$(document).ready(function() {
	// InField Labels
	$("label").inFieldLabels();
});